<?php
/**
 * ajax -> data -> upload
 * 
 * @package Sngine v2+
 * @author Zamblek
 */

// fetch bootstrap
require('../../../bootstrap.php');

// check AJAX Request
is_ajax();

// check user logged in
if(!$user->_logged_in) {
    modal(LOGIN);
}

// check user activated
if($system['email_send_activation'] && !$user->_data['user_activated']) {
    modal(MESSAGE, __("Not Activated"), __("Before you can interact with other users, you need to confirm your email address"));
}

// check secret
if($_SESSION['secret'] != $_POST['secret']) {
    _error(403);
}

// valid inputs
if(!isset($_FILES["file"]) || $_FILES["file"]["error"] != UPLOAD_ERR_OK) {
    modal(MESSAGE, __("Upload Error"), __("Something wrong with upload! Is 'upload_max_filesize' set correctly?"));
}
/* if file size is bigger than allowed size */
if($_FILES["file"]["size"] > 5242880) {
    modal(MESSAGE, __("Upload Error"), __("The file size is so big"));
}
/* if file is not an image */
if(!valid_image_type($_FILES["file"]["type"])) {
    modal(MESSAGE, __("Upload Error"), __("The file type is not valid image"));
}

$file_name  = strtolower($_FILES['file']['name']);
$file_ext = substr($file_name, strrpos($file_name, '.'));
$prefix = 'sngine_'.md5(time()*rand(1, 9999));
$file_name_new = $prefix.$file_ext;
$path = '../../../'.$system['system_uploads_directory'].'/'.$file_name_new;

// upload
try {

    /* check if the file uploaded successfully */
    if(!@move_uploaded_file($_FILES['file']['tmp_name'], $path)) {
        modal(MESSAGE, __("Upload Error"), __("Sorry, can not upload the file"));
    }

    // check the handle
    if(isset($_POST['handle'])) {
        switch ($_POST['handle']) {
            case 'cover-user':
                /* update user cover */
                $db->query(sprintf("UPDATE users SET user_cover = %s WHERE user_id = %s", secure($file_name_new), secure($user->_data['user_id'], 'int') )) or _error(SQL_ERROR_THROWEN);
                break;

            case 'picture-user':
                /* update user picture */
                $db->query(sprintf("UPDATE users SET user_picture = %s WHERE user_id = %s", secure($file_name_new), secure($user->_data['user_id'], 'int') )) or _error(SQL_ERROR_THROWEN);
                break;

            case 'cover-page':
                /* check if page id is set */
                if(!isset($_POST['id']) || !is_numeric($_POST['id'])) {
                    /* delete the uploaded image & return error 403 */
                    unlink($path);
                    _error(403);
                }
                /* check if the user is the page admin */
                $check = $db->query(sprintf("SELECT * FROM pages WHERE page_id = %s AND page_admin = %s", secure($_POST['id'], 'int'), secure($user->_data['user_id'], 'int') )) or _error(SQL_ERROR_THROWEN);
                if($check->num_rows == 0) {
                    /* delete the uploaded image & return error 403 */
                    unlink($path);
                    _error(403);
                }
                /* update page cover */
                $db->query(sprintf("UPDATE pages SET page_cover = %s WHERE page_id = %s", secure($file_name_new), secure($_POST['id'], 'int') )) or _error(SQL_ERROR_THROWEN);
                break;

            case 'picture-page':
                /* check if page id is set */
                if(!isset($_POST['id']) || !is_numeric($_POST['id'])) {
                    /* delete the uploaded image & return error 403 */
                    unlink($path);
                    _error(403);
                }
                /* check if the user is the page admin */
                $check = $db->query(sprintf("SELECT * FROM pages WHERE page_id = %s AND page_admin = %s", secure($_POST['id'], 'int'), secure($user->_data['user_id'], 'int') )) or _error(SQL_ERROR_THROWEN);
                if($check->num_rows == 0) {
                    /* delete the uploaded image & return error 403 */
                    unlink($path);
                    _error(403);
                }
                /* update page picture */
                $db->query(sprintf("UPDATE pages SET page_picture = %s WHERE page_id = %s", secure($file_name_new), secure($_POST['id'], 'int') )) or _error(SQL_ERROR_THROWEN);
                break;

            case 'cover-group':
                /* check if group id is set */
                if(!isset($_POST['id']) || !is_numeric($_POST['id'])) {
                    /* delete the uploaded image & return error 403 */
                    unlink($path);
                    _error(403);
                }
                /* check if the user is the group admin */
                $check = $db->query(sprintf("SELECT * FROM groups WHERE group_id = %s AND group_admin = %s", secure($_POST['id'], 'int'), secure($user->_data['user_id'], 'int') )) or _error(SQL_ERROR_THROWEN);
                if($check->num_rows == 0) {
                    /* delete the uploaded image & return error 403 */
                    unlink($path);
                    _error(403);
                }
                /* update group cover */
                $db->query(sprintf("UPDATE groups SET group_cover = %s WHERE group_id = %s", secure($file_name_new), secure($_POST['id'], 'int') )) or _error(SQL_ERROR_THROWEN);
                break;

            case 'picture-group':
                /* check if group id is set */
                if(!isset($_POST['id']) || !is_numeric($_POST['id'])) {
                    /* delete the uploaded image & return error 403 */
                    unlink($path);
                    _error(403);
                }
                /* check if the user is the group admin */
                $check = $db->query(sprintf("SELECT * FROM groups WHERE group_id = %s AND group_admin = %s", secure($_POST['id'], 'int'), secure($user->_data['user_id'], 'int') )) or _error(SQL_ERROR_THROWEN);
                if($check->num_rows == 0) {
                    /* delete the uploaded image & return error 403 */
                    unlink($path);
                    _error(403);
                }
                /* update group picture */
                $db->query(sprintf("UPDATE groups SET group_picture = %s WHERE group_id = %s", secure($file_name_new), secure($_POST['id'], 'int') )) or _error(SQL_ERROR_THROWEN);
                break;
        }
    }
    
    // return the file new name & exit
    return_json(array("file" => $file_name_new));

}catch (Exception $e) {
    modal(ERROR, __("Error"), $e->getMessage());
}
    

?>